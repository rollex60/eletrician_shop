from django.apps import AppConfig


class ElectricConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'electric'
