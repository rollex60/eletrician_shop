from django.contrib import admin

from electric.models import Electric

admin.site.register(Electric)
